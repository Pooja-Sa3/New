from django.apps import AppConfig


class AudioplayerConfig(AppConfig):
    name = 'audioPlayer'
