from django.db import models
from django.http import JsonResponse

# Create your models here.
class song(models.Model):
    id = models.BigAutoField(primary_key=True)
    name_of_the_song = models.CharField(max_length=100)
    duration_time= models.DecimalField((u'duration_time'), decimal_places=2, max_digits=12, validators=[MinValueValidator(Decimal('0.01'))])
    uploaded_on= models.DateField()
    return JsonResponse(data)
    

class Podcast(models.Model):
    id = models.BigAutoField(primary_key=True)
    name_of_the_podcast=models.CharField(max_length=100)
    duration_time= models.DecimalField((u'duration_time'), decimal_places=2, max_digits=12, validators=[MinValueValidator(Decimal('0.01'))])
    uploaded_on= models.DateField()
    Host_name=models.CharField(max_length=100)
    return JsonResponse(data)
    

class AudioBook(models.Model):
    id = models.BigAutoField(primary_key=True)
    name_of_the_audioBook=models.CharField(max_length=100)
    duration_time= models.DecimalField((u'duration_time'), decimal_places=2, max_digits=12, validators=[MinValueValidator(Decimal('0.01'))])
    uploaded_on= models.DateField()
    Author_name=models.CharField(max_length=100)
    Narrator_name=models.CharField( max_length=100)
    return JsonResponse(data)







