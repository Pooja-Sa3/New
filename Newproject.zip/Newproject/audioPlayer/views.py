from django.shortcuts import render, HttpResponse

from .models import song

# Create your views here.
def index(request):
    return HttpResponse("AUDIO FILE SYSTEM")

def create(request):
    d=['mp3','mp4','m4a']
    request.get('audiotype')    
    if audiotype in d:
        return HttpResponse("Valid")

def checkfile(request, pk):
    song = get_object_or_404(song, pk=pk)
    data = {"results": {
        "song": song.name_of_the_song,
        "duration": duration_time,
        "uploaded": uploaded_on
    }}
    return JsonResponse(data)


def response_error_handler(request, exception=None):
    return HttpResponse('Error handler content', status=400)


