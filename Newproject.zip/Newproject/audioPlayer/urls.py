from django.contrib import admin
from django.urls import path, include
from audioPlayer import views
from .models import songs

urlpatterns = [
    path("", views.index, name= 'home'),
    path("audioFileType", views.create, name='audioFileType')
    path("audioFileType/","audioFileID/<int:pk>/", views.checkfile, name='audio')
    path("podcast/<int:id>/",views.podcastdetail, name='podcastdetails')
    
]
